from django.apps import AppConfig


class ShortUrlConfig(AppConfig):
    name = 'short_url'
