from django.apps import AppConfig


class KeysAdminConfig(AppConfig):
    name = 'keys_admin'
