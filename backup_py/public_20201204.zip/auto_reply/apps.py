from django.apps import AppConfig


class AutoReplyConfig(AppConfig):
    name = 'auto_reply'
